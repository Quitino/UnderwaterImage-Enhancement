# neural_net
Neural netwrok to recognize and dehaze underwater images using Tensorflow. 
For additional information contact us: 
Aleks Attanasio: (aleks.attanasio@gmail.com), Nataliya Nechyporenko (nataliya.nechyporenko@gmail.com) 
The code requires a sizable image file "Dehazing Datasets." It will shortly be uploaded online, and the link will be provided. 
In the mean time please ask us for the folder and we will send it to you. 
Requires Tensorflow, Python 2.7 or above, and other packages. 
Run dehaze.py or recognize.py within the neural_net folder to obtain results stored in the Results and Accuracy Folders. 
Modify paramters as specified in the code. 
Let us know if you have any questions. 
